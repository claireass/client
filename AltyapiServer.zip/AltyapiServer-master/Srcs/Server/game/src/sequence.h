#define SEQUENCE_MAX_NUM	32768

extern const BYTE gc_abSequence[SEQUENCE_MAX_NUM];
