/*********************************************************************
 * date        : 2007.06.07
 * file        : teen_packet.h
 * author      : mhh
 * description : 
 */

#ifndef _teen_packet_h_
#define _teen_packet_h_

#define HEADER_GT_LOGIN		0x10
#define HEADER_GT_LOGOUT	0x11


#define HEADER_TG_TEEN_NOTICE	0x12
#define HEADER_TG_FORCE_LOGOUT	0x13
#define HEADER_TG_LOGIN_NOTICE	0x14

#endif	/* _teen_packet_h_ */

