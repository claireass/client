#ifndef __INC_SERVICE_H__
#define __INC_SERVICE_H__

#define _IMPROVED_PACKET_ENCRYPTION_ // ��Ŷ ��ȣȭ ����
//#define __AUCTION__
#define __PET_SYSTEM__
#define __UDP_BLOCK__
#endif
